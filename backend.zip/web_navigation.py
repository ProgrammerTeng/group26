from oscopilot import FridayAgent
from oscopilot import ToolManager
from oscopilot import FridayExecutor, FridayPlanner, FridayRetriever
from oscopilot.utils import setup_config, setup_pre_run

# 设置配置
args = setup_config()

# 提供选项
print("请选择一个选项:")
print("1. 打开百度")
print("2. 打开谷歌")

# 获取用户输入
user_choice = input("请输入选项 (1 或 2): ")

# 根据用户选择设置查询
if user_choice == "1":
    args.query = "open https://www.baidu.com"
elif user_choice == "2":
    args.query = "open https://www.google.com"
else:
    print("无效选择，默认打开百度。")
    args.query = "open https://www.baidu.com"

# 设置任务
task = setup_pre_run(args)

# 创建代理并运行任务
agent = FridayAgent(FridayPlanner, FridayRetriever, FridayExecutor, ToolManager, config=args)
agent.run(task=task)