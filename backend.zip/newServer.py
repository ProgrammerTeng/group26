from flask import Flask, jsonify
from flask_cors import CORS
import json
import time
import os
app = Flask(__name__)
CORS(app)  # 启用 CORS

def write_jsonl(filename, data, mode='a'):
    with open(filename, mode) as f:
        for entry in data:
            f.write(json.dumps(entry) + '\n')

def read_jsonl(filename):
    if not os.path.exists(filename):
        return []
    with open(filename, 'r') as f:
        return [json.loads(line) for line in f]

def get_recommendation(stock_code, recommendations):
    for rec in recommendations:
        if rec['stock_code'] == stock_code:
            return rec['recommendation']
    return None
@app.route('/api/send', methods=['GET'])  # 使用 GET 方法
def send():
    # 导入必要的模块
    from oscopilot import FridayAgent, ToolManager, FridayExecutor, FridayPlanner, FridayRetriever
    from oscopilot.utils import setup_config, setup_pre_run

    try:
        # 设置配置
        args = setup_config()

        # 如果没有 query，则设置默认值
        if not args.query:
            args.query = "open recommend system"

        # 准备任务
        task = setup_pre_run(args)

        # 创建代理并运行任务
        agent = FridayAgent(FridayPlanner, FridayRetriever, FridayExecutor, ToolManager, config=args)
        #agent.run(task=task)  # 确保这个方法是阻塞的，直到完成
        stock_code = input("Please enter the stock code: ").strip().upper()
        recommendations = read_jsonl('stock_recommendations.jsonl')

        recommendation = get_recommendation(stock_code, recommendations)
        if recommendation:
            print(f"The recommendation for stock code {stock_code} is:\n{recommendation}")
        else:
            print(f"No recommendation found for stock code {stock_code}.")

        predictions = []

        total_tokens = 0
        start_time = time.time()

        existing_recommendations = read_jsonl('stock_recommendations.jsonl')

        return jsonify({"message": "Request received successfully."}), 200

    except Exception as e:
        # 处理可能的异常
        print(f"Error occurred: {e}")  # 打印错误信息
        return jsonify({"error": "An error occurred during processing."}), 500






if __name__ == '__main__':
    app.run(port=5000, debug=True)  # 启用调试模式
















