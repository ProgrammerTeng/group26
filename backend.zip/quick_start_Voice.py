import os
import sys
import json
import base64
import time
import wave
import pyaudio
import argparse
from urllib.request import urlopen, Request
from urllib.error import URLError
from urllib.parse import urlencode
from oscopilot import FridayAgent
from oscopilot import ToolManager
from oscopilot import FridayExecutor, FridayPlanner, FridayRetriever
from oscopilot.utils import setup_config, setup_pre_run

API_KEY = 'ZBzORx2Nq2CIByfd5jobPlmL'
SECRET_KEY = 'EK1HmhZUOvdiDt81qbRw2OS81vYNzkVj'
ASR_URL = 'http://vop.baidu.com/server_api'
DEV_PID = 1737  # 中文识别
CUID = '123456PYTHON'
RATE = 16000
FORMAT = 'pcm'
TOKEN_URL = 'http://aip.baidubce.com/oauth/2.0/token'


class DemoError(Exception):
    pass


def fetch_token():
    params = {
        'grant_type': 'client_credentials',
        'client_id': API_KEY,
        'client_secret': SECRET_KEY
    }
    post_data = urlencode(params).encode('utf-8')
    req = Request(TOKEN_URL, post_data)

    try:
        f = urlopen(req)
        result_str = f.read().decode()
        result = json.loads(result_str)
        if 'access_token' in result:
            return result['access_token']
        else:
            raise DemoError('API_KEY or SECRET_KEY might not be correct')
    except URLError as err:
        print('Token HTTP response error:', err)
        raise


def record_audio(output_file, record_seconds=5):
    chunk = 1024
    format = pyaudio.paInt16
    channels = 1

    p = pyaudio.PyAudio()
    stream = p.open(format=format, channels=channels, rate=RATE, input=True, frames_per_buffer=chunk)

    print("Recording...")
    frames = []

    for _ in range(0, int(RATE / chunk * record_seconds)):
        data = stream.read(chunk)
        frames.append(data)

    print("Recording finished.")
    stream.stop_stream()
    stream.close()
    p.terminate()

    with wave.open(output_file, 'wb') as wf:
        wf.setnchannels(channels)
        wf.setsampwidth(p.get_sample_size(format))
        wf.setframerate(RATE)
        wf.writeframes(b''.join(frames))


def process_audio(input_file):
    with open(input_file, 'rb') as speech_file:
        speech_data = speech_file.read()

    if len(speech_data) == 0:
        raise DemoError('File length is 0 bytes')

    speech = base64.b64encode(speech_data).decode('utf-8')
    token = fetch_token()

    params = {
        'dev_pid': DEV_PID,
        'format': FORMAT,
        'rate': RATE,
        'token': token,
        'cuid': CUID,
        'channel': 1,
        'speech': speech,
        'len': len(speech_data)
    }

    post_data = json.dumps(params).encode('utf-8')
    req = Request(ASR_URL, post_data)
    req.add_header('Content-Type', 'application/json')

    try:
        begin = time.perf_counter()
        f = urlopen(req)
        result_str = f.read().decode('utf-8')
        print("Request time cost %f seconds" % (time.perf_counter() - begin))
        return json.loads(result_str)
    except URLError as err:
        print('ASR HTTP response error:', err)
        raise


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Process some arguments.')
    parser.add_argument('--query', type=str, help='The query to process')
    args = parser.parse_args()
    args = setup_config()

    user_input = input("Would you like to perform voice input? (y/n): ").strip().lower()
    if user_input == 'y':
        audio_file = 'audio/16k.pcm'
        os.makedirs(os.path.dirname(audio_file), exist_ok=True)  # 确保目录存在
        record_audio(audio_file, record_seconds=5)

        try:
            result_json = process_audio(audio_file)
            if 'result' in result_json:
                args.query = result_json['result'][0]
            else:
                print("No valid speech recognition result found.")
                sys.exit(1)
        except DemoError as e:
            print(e)
            sys.exit(1)
    else:
        if not args.query:
            args.query = "create a folder called '11'"  # 默认查询

    task = setup_pre_run(args)

    # 初始化 FridayAgent
    agent = FridayAgent(FridayPlanner, FridayRetriever, FridayExecutor, ToolManager, config=args)

    # 调用 `run` 方法，传入任务
    agent.run(task=task)