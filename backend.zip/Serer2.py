from flask import Flask, request, jsonify
from flask_cors import CORS
from oscopilot import FridayAgent
from oscopilot import ToolManager
from oscopilot import FridayExecutor, FridayPlanner, FridayRetriever
from oscopilot.utils import setup_config, setup_pre_run

app = Flask(__name__)
CORS(app)  # 启用 CORS，允许跨域请求


@app.route('/api/send', methods=['POST'])
def send():
    # 获取 JSON 数据
    data = request.json

    # 从请求中提取 prompts 内容
    prompts = data.get('prompts')

    if not prompts:
        return jsonify({"error": "No prompts provided."}), 400

    # 这里可以添加处理 prompts 的逻辑
    #print(f"Received prompts: {prompts}")  # 打印接收到的内容
    args = setup_config()
    if not args.query:
        args.query = (prompts)
    task = setup_pre_run(args)
    agent = FridayAgent(FridayPlanner, FridayRetriever, FridayExecutor, ToolManager, config=args)
    agent.run(task=task)

    # 假设处理完成后返回成功响应
    return jsonify({"message": "Request received successfully.", "prompts": prompts}), 200


if __name__ == '__main__':
    app.run(port=5000, debug=True)  # 启用调试模式