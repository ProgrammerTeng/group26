from oscopilot import FridayAgent
from oscopilot import ToolManager
from oscopilot import FridayExecutor, FridayPlanner, FridayRetriever
from oscopilot.utils import setup_config, setup_pre_run
import random

# 存储用户的历史搜索记录
search_history = []


def recommend_queries(history):
    """
    根据历史搜索记录推荐查询。

    Args:
        history (list): 存储用户搜索历史的列表。

    Returns:
        list: 推荐的查询列表。
    """
    # 如果没有历史搜索，返回默认推荐
    if not history:
        return ["打开Google", "查看天气", "查询股票"]

    # 基于历史的推荐
    recommendations = []

    # 随机选择历史搜索中的一个作为推荐
    if history:
        recommendations.append(random.choice(history))

    # 添加与历史查询相似的推荐（简单的示例）
    for query in history:
        if "网站" in query:
            recommendations.append("打开其他网站")
        elif "查询" in query:
            recommendations.append("查询最新信息")

    # 去重
    recommendations = list(set(recommendations))

    return recommendations


# 设置配置
args = setup_config()

# 初始化问题列表
questions = []

# 检查是否有查询，如果没有则设置默认查询
if not args.query:
    args.query = ("打开outlook邮箱网站")

# 将当前查询保存到列表中
questions.append(args.query)

# 更新历史搜索记录
search_history.append(args.query)

# 设置任务
task = setup_pre_run(args)

# 创建代理
agent = FridayAgent(FridayPlanner, FridayRetriever, FridayExecutor, ToolManager, config=args)

# 执行任务
agent.run(task=task)

# 获取推荐查询
recommended_queries = recommend_queries(search_history)

# 输出推荐的查询
print("推荐的查询:", recommended_queries)

# 打印所有存储的问题
print("存储的问题列表:")
for question in questions:
    print(question)