import json
import time
import os

def fetch_data(stock_code):
    # 模拟获取股票数据的函数
    pass

def get_model_answer(stock_data):
    # 模拟获取模型答案的函数
    pass

def write_jsonl(filename, data, mode='a'):
    with open(filename, mode) as f:
        for entry in data:
            f.write(json.dumps(entry) + '\n')

def read_jsonl(filename):
    if not os.path.exists(filename):
        return []
    with open(filename, 'r') as f:
        return [json.loads(line) for line in f]

if __name__ == '__main__':
    stock_codes = ['AAPL', 'TSLA', 'GOOGL']  # 示例股票代码
    predictions = []

    total_tokens = 0
    start_time = time.time()

    existing_recommendations = read_jsonl('stock_recommendations.jsonl')
    existing_stock_codes = {rec['stock_code']: rec['recommendation'] for rec in existing_recommendations}

    for stock_code in stock_codes:
        if stock_code in existing_stock_codes:
            print(f"Recommendation for stock code {stock_code} already exists: {existing_stock_codes[stock_code]}")
            continue

        data = fetch_data(stock_code)
        if data.empty:
            print(f"Failed to download stock data: {stock_code}")
            continue

        stock_data = data.to_json()
        try:
            model_answer, tokens = get_model_answer(stock_data)
            predictions.append({'stock_code': stock_code, 'recommendation': model_answer})
            total_tokens += tokens
        except Exception as e:
            print(f"Failed to get completion for stock: {stock_code}, error: {e}")

        time.sleep(3)

    if predictions:
        write_jsonl('stock_recommendations.jsonl', predictions, mode='a')

    end_time = time.time()
    wall_clock_time = end_time - start_time
    avg_tokens_per_stock = total_tokens / len(stock_codes)

    print(f'Wall-clock time: {wall_clock_time:.2f} seconds')
    print(f'Average tokens per stock: {avg_tokens_per_stock:.2f}')